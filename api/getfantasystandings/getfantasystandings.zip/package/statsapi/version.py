#!/usr/bin/env python

VERSION = "1.0.0"
